<?php
//The index.php file is required to load the correct plugin class.
require_once('AudioPlayerPlugin.inc.php');
return new AudioPlayerPlugin();
